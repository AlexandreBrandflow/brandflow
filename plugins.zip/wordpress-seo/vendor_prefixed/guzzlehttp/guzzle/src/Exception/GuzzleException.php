<?php

namespace YoastSEO_Vendor\GuzzleHttp\Exception;

use YoastSEO_Vendor\Psr\Http\Client\ClientExceptionInterface;
interface GuzzleException extends \YoastSEO_Vendor\Psr\Http\Client\ClientExceptionInterface
{
}
