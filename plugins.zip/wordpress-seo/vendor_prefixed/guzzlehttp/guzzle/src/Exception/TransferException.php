<?php

namespace YoastSEO_Vendor\GuzzleHttp\Exception;

class TransferException extends \RuntimeException implements \YoastSEO_Vendor\GuzzleHttp\Exception\GuzzleException
{
}
