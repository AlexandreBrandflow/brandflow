<?php
/**
 * The capture entity.
 *
 * @link https://developer.paypal.com/docs/api/orders/v2/#definition-capture
 *
 * @package Woocommerce\PayPalCommerce\ApiClient\Entity
 */

declare( strict_types=1 );

namespace Woocommerce\PayPalCommerce\ApiClient\Entity;

/**
 * Class Capture
 */
class Capture {

	/**
	 * The ID.
	 *
	 * @var string
	 */
	private $id;

	/**
	 * The status.
	 *
	 * @var string
	 */
	private $status;

	/**
	 * The status details.
	 *
	 * @var string
	 */
	private $status_details;

	/**
	 * The amount.
	 *
	 * @var Amount
	 */
	private $amount;

	/**
	 * Whether this is the final capture or not.
	 *
	 * @var bool
	 */
	private $final_capture;

	/**
	 * The seller protection.
	 *
	 * @var string
	 */
	private $seller_protection;

	/**
	 * The invoice id.
	 *
	 * @var string
	 */
	private $invoice_id;

	/**
	 * The custom id.
	 *
	 * @var string
	 */
	private $custom_id;

	/**
	 * Capture constructor.
	 *
	 * @param string $id The ID.
	 * @param string $status The status.
	 * @param string $status_details The status details.
	 * @param Amount $amount The amount.
	 * @param bool   $final_capture The final capture.
	 * @param string $seller_protection The seller protection.
	 * @param string $invoice_id The invoice id.
	 * @param string $custom_id The custom id.
	 */
	public function __construct(
		string $id,
		string $status,
		string $status_details,
		Amount $amount,
		bool $final_capture,
		string $seller_protection,
		string $invoice_id,
		string $custom_id
	) {

		$this->id                = $id;
		$this->status            = $status;
		$this->status_details    = $status_details;
		$this->amount            = $amount;
		$this->final_capture     = $final_capture;
		$this->seller_protection = $seller_protection;
		$this->invoice_id        = $invoice_id;
		$this->custom_id         = $custom_id;
	}

	/**
	 * Returns the ID.
	 *
	 * @return string
	 */
	public function id() : string {
		return $this->id;
	}

	/**
	 * Returns the status.
	 *
	 * @return string
	 */
	public function status() : string {
		return $this->status;
	}

	/**
	 * Returns the status details object.
	 *
	 * @return \stdClass
	 */
	public function status_details() : \stdClass {
		return (object) array( 'reason' => $this->status_details );
	}

	/**
	 * Returns the amount.
	 *
	 * @return Amount
	 */
	public function amount() : Amount {
		return $this->amount;
	}

	/**
	 * Returns whether this is the final capture or not.
	 *
	 * @return bool
	 */
	public function final_capture() : bool {
		return $this->final_capture;
	}

	/**
	 * Returns the seller protection object.
	 *
	 * @return \stdClass
	 */
	public function seller_protection() : \stdClass {
		return (object) array( 'status' => $this->seller_protection );
	}

	/**
	 * Returns the invoice id.
	 *
	 * @return string
	 */
	public function invoice_id() : string {
		return $this->invoice_id;
	}

	/**
	 * Returns the custom id.
	 *
	 * @return string
	 */
	public function custom_id() : string {
		return $this->custom_id;
	}

	/**
	 * Returns the entity as array.
	 *
	 * @return array
	 */
	public function to_array() : array {
		return array(
			'id'                => $this->id(),
			'status'            => $this->status(),
			'status_details'    => (array) $this->status_details(),
			'amount'            => $this->amount()->to_array(),
			'final_capture'     => $this->final_capture(),
			'seller_protection' => (array) $this->seller_protection(),
			'invoice_id'        => $this->invoice_id(),
			'custom_id'         => $this->custom_id(),
		);
	}
}
